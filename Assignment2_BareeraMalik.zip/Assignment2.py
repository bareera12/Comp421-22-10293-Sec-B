
import rsa
public_key, private_key = rsa.newkeys(512)

i=1
while i==1:              #loop to keep the program running until user exits

    #RSA ENCRYPTON ALGORITHM
    def encryption(plain_text):
        plain_text = plain_text.encode('utf8')
        encrypted_text = rsa.encrypt(plain_text, public_key)
        return encrypted_text

    #RSA DECRYPTION ALGORITHM
    def decryption(encrypted_text):
        decrypted_text = rsa.decrypt(encrypted_text, private_key)
        return decrypted_text.decode("utf-8")

    _plainText = input("Enter a string: ")         #entering plain text
    print("The plain text that will be encrypted is: ", _plainText)   #printing plain text

    _encryptedText = encryption(_plainText)        #encryprting the text
    print("Encrypted text = %s" %(_encryptedText))   

    _decryptedText = decryption(_encryptedText)         #decrypting the text
    print("Decrypted text = %s" %(_decryptedText))

    status=input("Do you want run this program again?(Y/N): ")
    if ((status=="Y") or (status=="Yes") or (status=="YES")):
        i=1
    else:
        i=0



    
